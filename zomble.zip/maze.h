#ifndef _maze_h
#define _maze_h
void maze(void);
#endif
