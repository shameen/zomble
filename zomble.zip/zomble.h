#ifndef _zomble_h
#define _zomble_h
void zomble(void);
#endif
