#ifndef _AD_CONV
#define _AD_CONV

/* functions */
void InitAd(void); // to be used at the beginning to initialize AD
int ReadAd(unsigned int channel); // simple function to sample one channel

#endif
