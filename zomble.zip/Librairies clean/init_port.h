#ifndef _INIT_PORT
#define _INIT_PORT


/* functions */
void InitPort(void);

#endif

