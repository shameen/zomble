#ifndef _love_h
#define _love_h
void love(void);
#endif
