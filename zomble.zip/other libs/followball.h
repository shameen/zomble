#ifndef _BREITENBERG
#define _BREITENBERG

void run_breitenberg_follower(void);
void run_breitenberg_shocker(void);

#endif
