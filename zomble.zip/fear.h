#ifndef _fear_h
#define _fear_h
void fear(void);
#endif
