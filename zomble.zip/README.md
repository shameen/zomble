zomble
======

e-puck basic robot behaviours + more advanced zombie behaviour

switches:
---------

0 - Aggressive

1 - Fear

2 - Curious

3 - Love

8 - Zomble