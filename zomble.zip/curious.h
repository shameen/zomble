#ifndef _curious_h
#define _curious_h
void curious(void);
#endif
